//
//  ViewController.swift
//  I am Rich
//
//  Created by Livia Carvalho Keller on 11/08/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

